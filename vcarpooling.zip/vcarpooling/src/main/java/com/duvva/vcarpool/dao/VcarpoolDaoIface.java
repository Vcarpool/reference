package com.duvva.vcarpool.dao;

import com.duvva.vcarpool.entity.Employee;
import com.duvva.vcarpool.entity.Provider;

public interface VcarpoolDaoIface {
	
	String GET_POOLDETAILS = "FROM Provider WHERE employeeid = :employee_id and status='Active'";
	String GET_EMPLOYEEDETAILS="FROM Employee WHERE employeeid=:employee_id and password=:pass";
	String GENERATE_POOLID="FROM Provider";
	String CHECK_EMPLOYEE="FROM Employee WHERE employeeid=:employee_id and sq=:sq and sa=:sa";
	String UPDATE_PASS="Update Employee e set e.passkey=:pass where e.employeeId=:empid" ;
	//String UPDATE_PROFILE="Update Employee  set name=:name,emailId=,Occupation=?,country=?,City=?,Gender=?,mobile=? where employeeid=:empid;"
	
	Boolean addEmployee(Employee employee);
	Employee authenticateEmployee(int employeeid,String pass);
	Provider getPoolDetails(int employeeid);
	int autoGeneratePoolId();
	Boolean createPool(Provider provider);
	Employee checkEmployee(Employee employee);
	Boolean updatePass(int employeeid,String pass);
}
