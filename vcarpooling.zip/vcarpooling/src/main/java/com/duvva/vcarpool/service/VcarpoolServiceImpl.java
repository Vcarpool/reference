package com.duvva.vcarpool.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.duvva.vcarpool.dao.VcarpoolDaoIface;
import com.duvva.vcarpool.entity.Employee;
import com.duvva.vcarpool.entity.Provider;
@Repository
public class VcarpoolServiceImpl implements VcarpoolServiceIface {
@Autowired
VcarpoolDaoIface vdao;

	public VcarpoolDaoIface getVdao() {
	return vdao;
}
public void setVdao(VcarpoolDaoIface vdao) {
	this.vdao = vdao;
}
	public Boolean addEmployee(Employee employee) {
		return vdao.addEmployee(employee);
	}
	public Employee authenticateEmployee(int employeeid, String pass) {
		return vdao.authenticateEmployee(employeeid, pass);
	}
	public Provider getPoolDetails(int employeeid) {
//		System.out.println("HAI"+vdao);
		return vdao.getPoolDetails(employeeid);
	}
	
	public int generatePoolId() {
//		System.out.println("HAI 22"+vdao);
		return vdao.autoGeneratePoolId();
	}
	public Boolean createPool(Provider provider) {
		// TODO Auto-generated method stub
		return vdao.createPool(provider);
	}
	public Employee checkEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return vdao.checkEmployee(employee);
	}
	public Boolean updatePass(int employeeid, String pass) {
		// TODO Auto-generated method stub
		return vdao.updatePass(employeeid, pass);
	}

	

}
