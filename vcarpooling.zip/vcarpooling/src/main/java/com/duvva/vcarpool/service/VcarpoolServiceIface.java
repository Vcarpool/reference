package com.duvva.vcarpool.service;

import com.duvva.vcarpool.entity.Employee;
import com.duvva.vcarpool.entity.Provider;

public interface VcarpoolServiceIface {
	Boolean addEmployee(Employee employee);
	Employee authenticateEmployee(int employeeid,String pass);
	Provider getPoolDetails(int employeeid);
	int generatePoolId();
	Boolean createPool(Provider provider);
	Employee checkEmployee(Employee employee);
	Boolean updatePass(int employeeid,String pass);
}
