package com.duvva.vcarpool.dao;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.duvva.vcarpool.entity.Employee;
import com.duvva.vcarpool.entity.Provider;

@Repository
public class VcarpoolDaoImpl implements VcarpoolDaoIface {
	
@Autowired
private SessionFactory session;

public VcarpoolDaoImpl() {
	// TODO Auto-generated constructor stub
}
	public SessionFactory getSession() {
	return session;
}
	
public void setSession(SessionFactory session) {
	this.session = session;
}

@Transactional
	public Boolean addEmployee(Employee employee) {
	try {
	session.getCurrentSession().saveOrUpdate(employee);
	return true;
	}catch(Exception e) {
		return false;
	}
	}

@Transactional
public Employee authenticateEmployee(int employeeid,String pass) {
	
	Query query = session.getCurrentSession().createQuery(GET_EMPLOYEEDETAILS);
	query.setParameter("employee_id", employeeid);
	query.setParameter("pass", pass);
List<Employee> results = query.list();
	
	//Query query=session..createQuery("from provideride1 where employeeid=:n and status='Active'");
	
	//query.setParameter("n", employeeid);
	if(results.isEmpty()) {
		return null;
	}
	Employee employee=results.get(0);
		return employee;
}

@Transactional
public Provider getPoolDetails(int employeeid) {
	
	
	Query query = session.getCurrentSession().createQuery(GET_POOLDETAILS);
	query.setParameter("employee_id",employeeid );
	List<Provider> results = query.list();
	
	//Query query=session..createQuery("from provideride1 where employeeid=:n and status='Active'");
	
	//query.setParameter("n", employeeid);
	if(results.isEmpty()) {
		return null;
	}
	Provider provide=results.get(0);
		return provide;
}

@Transactional
public int autoGeneratePoolId() {
	//System.out.println("Session :"+session);
	Query query = session.getCurrentSession().createQuery(GENERATE_POOLID);
	//System.out.println(query);
	List<Provider> results = query.list();
	//System.out.println(results);
	if(results.isEmpty()) {
		return 1;
	}
	Provider provide=results.get(results.size()-1);
	//System.out.println(provide.getPoolId()+1);
	return provide.getPoolId()+1;
}

@Transactional
public Boolean createPool(Provider provider) {
	
	try {
	session.getCurrentSession().saveOrUpdate(provider);
	return true;
	}
	catch(Exception e) {
		return false;
	}
//	if(a>0) {
//		return true;
//	}
//	else {
//		return false;
//	}
}

@Transactional
public Employee checkEmployee(Employee employee) {
	
	Query query = session.getCurrentSession().createQuery(CHECK_EMPLOYEE);
	query.setParameter("employee_id",employee.getEmployeeId());
	query.setParameter("sq", employee.getSecurityQuestion());
	query.setParameter("sa", employee.getSecurityAnswer());
	List<Employee> results = query.list();
	if(results.isEmpty()) {
		return null;
	}
	Employee empl=results.get(0);
	return empl;

}

@Transactional
public Boolean updatePass(int employeeid, String pass) {
	// TODO Auto-generated method stub
	Query query = session.getCurrentSession().createQuery(UPDATE_PASS);
	query.setParameter("pass", pass);
	query.setParameter("empid",employeeid);
	//List<Employee> results = query.list();
	int empid=query.executeUpdate();
	System.out.println(empid);
	if(empid>0) {
		return true;
	}
	return false;
}

}
