package com.duvva.vcarpool.controller;

import com.duvva.vcarpool.service.VcarpoolServiceIface;
import com.duvva.vcarpool.service.VcarpoolServiceImpl;

public class Test {
public static void main(String[] args) {
	VcarpoolServiceIface vservice=new VcarpoolServiceImpl();
	System.out.println(vservice.getPoolDetails(8063741));
}
}
