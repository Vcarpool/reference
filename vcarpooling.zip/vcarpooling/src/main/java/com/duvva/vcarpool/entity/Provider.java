package com.duvva.vcarpool.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="provideride1")
public class Provider {
	
	@Id
	@Column(name = "poolid")
	private int poolId;
	@Column(name = "source")
	private String source;
	@Column(name = "destination")
	private String destination;
	@Column(name = "starttime")
	private String startTime;
	@Column(name = "returntime")
	private String returnTime;
	@Column(name = "noofseats")
	private int noOfSeats;
	@Column(name = "status")
	private String status;
	@Temporal(TemporalType.DATE) 
	@Column(name = "currentdate")
	private Date currentDate;
    @Column(name="employeeId")
	private int employeeId;
	
	public int getPoolId() {
		return poolId;
	}
	public void setPoolId(int poolId) {
		this.poolId = poolId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getReturnTime() {
		return returnTime;
	}
	public void setReturnTime(String returnTime) {
		this.returnTime = returnTime;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Date getCurrentDate() {
		return currentDate;
	}
	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	@Override
	public String toString() {
		return "Provider [poolId=" + poolId + ", source=" + source + ", destination=" + destination + ", startTime="
				+ startTime + ", returnTime=" + returnTime + ", noOfSeats=" + noOfSeats + ", status=" + status
				+ ", currentDate=" + currentDate + "employeeId=" + employeeId +"]";
	}

}
