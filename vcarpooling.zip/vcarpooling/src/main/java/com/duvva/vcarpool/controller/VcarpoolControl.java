package com.duvva.vcarpool.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.duvva.vcarpool.entity.Employee;
import com.duvva.vcarpool.entity.Provider;
import com.duvva.vcarpool.service.VcarpoolServiceIface;

@Controller
public class VcarpoolControl {
@Autowired
VcarpoolServiceIface vservice;

Employee employee1;
Provider provider1;
String utype;

	public Employee getEmployee1() {
	return employee1;
}

public void setEmployee1(Employee employee1) {
	this.employee1 = employee1;
}

	public VcarpoolServiceIface getVservice() {
	return vservice;
}

public void setVservice(VcarpoolServiceIface vservice) {
	this.vservice = vservice;
}

	@RequestMapping("/registertake")
	public String takeToAdd(Model m) {
		m.addAttribute("reg", new Employee());
		return "RegistrationPage";
	}
	
	@RequestMapping("/login")
	public String Login() {
		return "Login";
	}
	
	@RequestMapping("/RegistrationController")
	public String registerEmployee(@Valid @ModelAttribute("reg") Employee employee,BindingResult results) {
		if(results.hasErrors()) {
			return "RegistrationPage";
		}
		else {
			if(vservice.addEmployee(employee)) {
				return "Login";
			}
			else {
				return "Login";
			}
			
		}		

	}
	@RequestMapping("/check")
	public String check(@RequestParam("empid") int empid,Model mv) {
		Provider provider=vservice.getPoolDetails(empid);
		mv.addAttribute("data", provider);
		System.out.println(provider); 
		if(provider!=null) {
		return "display";
		}
		return "Login"; 
	}
	
	@RequestMapping("/AuthenticationUserController")
	public String authenticateEmployee(@RequestParam("txtEmpid") int employeeid, @RequestParam("txtPwd") String pass,@RequestParam("utype") String utype,Model mv) {
		try{
			Employee emp=vservice.authenticateEmployee(employeeid, pass);
		System.out.println(emp.getEmployeeName());
		this.employee1=emp;
		this.utype=utype;
		mv.addAttribute("EmpDetails", emp);
		if(emp!=null) {
			//mv.addAttribute("Utype", utype);
				if(utype.equals("provider")) {
					Provider provider=vservice.getPoolDetails(employeeid);
					if(provider!=null) {
						mv.addAttribute("poolDetails", provider);
						this.provider1=provider;
						return "ProviderHomePage";
					}
					else {
						//mv.addAttribute("EmpDetails", emp);
						mv.addAttribute("poolid", vservice.generatePoolId());
						mv.addAttribute("newprovider", new Provider());
						return "CreatePool";
					}
			}
			if(utype.equals("rider")) {
				return "FindRideAfterLogin";
			}
			
		}
		}
		catch(Exception e) {
			return "Login";
		}
		return "Login";

	}
	
	@RequestMapping("/Createpool")
	public String taketocreate(Model mv) {
		mv.addAttribute("poolid", vservice.generatePoolId());
		mv.addAttribute("newprovider", new Provider());
		mv.addAttribute("EmpDetails", employee1);
		return "CreatePool";
	}
	
	@RequestMapping("/CreatePoolController")
	public String createPool(@Valid @ModelAttribute("newprovider") Provider provider,BindingResult results,Model mv) {
		System.out.println("Hello");
//		if(results.hasErrors()) {
//			mv.addAttribute("createpool", new Provider());
//			return "CreatePool";
//		} 
		System.out.println(employee1.getEmployeeName());
			if(vservice.createPool(provider)) {
				System.out.println(provider.getEmployeeId());
				System.out.println(employee1.getEmployeeName());
				mv.addAttribute("EmpDetails", employee1);
				Provider provider2=vservice.getPoolDetails(provider.getEmployeeId());
				if(provider2!=null) {
					this.provider1=provider2;
					mv.addAttribute("poolDetails", provider2);
					return "ProviderHomePage";
				}
				mv.addAttribute("poolid", vservice.generatePoolId());
				return "CreatePool";
			}
			else {
				mv.addAttribute("poolid", vservice.generatePoolId());
				System.out.println("Hai");
				return "CreatePool";
			}
	}

    @RequestMapping("/taketoupdate")
    public String takeToUpdate(Model mv) {
    	mv.addAttribute("poolDetails", provider1);
    	mv.addAttribute("EmpDetails", employee1);
    	mv.addAttribute("newprovider", new Provider());
		return "UpdatePool";
    	
    }
    
    @RequestMapping("/forgotpasstake")
    public String takeToForgotPass(Model mv) {
    	mv.addAttribute("EmpDetails", employee1);
    	return "ForgotCredentials";
    }
	
    @RequestMapping("/ForgotCredentialsController")
    public String forgotCredentials(@ModelAttribute("EmpDetails") Employee employee,Model mv) {
    	employee1=vservice.checkEmployee(employee);
    	System.out.println("emo");
		if(employee1!=null) {
			mv.addAttribute("EmpDetails",employee1);
			return "ChangePass";
		}
    	return null;
    }
    
    @RequestMapping("/UpdatePassController")
    public String updatePass(@RequestParam("Employeeid") int employeeid,@RequestParam("newpwd") String pass,Model mv) {
    	if(vservice.updatePass(employeeid, pass)) {
    		return "Login";
    	}
    	mv.addAttribute("EmpDetails",employee1);
		return "ChangePass";
    }
    @RequestMapping("/TakeToProfileDisp")
    public String taketoprofile(Model mv) {
    	mv.addAttribute("Employee", employee1);
    	mv.addAttribute("Utype", utype);
		return "profile";   	
    }
    @RequestMapping("/UpdateProfController")
    public String updateProf(Model mv) {
    		
    	mv.addAttribute("Employee", employee1);
    	mv.addAttribute("Utype", utype);
    	//mv.addAttribute("emp", new Employee());
		return "UpdateProfile";
    	
    }
    @RequestMapping("/ProfUpdate")
    public String profUpd(@Valid @ModelAttribute("Employee") Employee employee,BindingResult res,Model mv)
    {
		
    	if(res.hasErrors()) {
			return "UpdateProfile";
		}
		else {
			if(vservice.addEmployee(employee)) {
				employee1=vservice.authenticateEmployee(employee1.getEmployeeId(), employee1.getPasskey());
				mv.addAttribute("Employee", employee1);
		    	mv.addAttribute("Utype", utype);
				return "profile";
			}
			else {
				mv.addAttribute("Employee", employee1);
		    	mv.addAttribute("Utype", utype);
				return "profile";
				
			}
			
		}			
    	
    }
    @RequestMapping("/TakeToChangePass")
    public String takeToChangePass(Model mv) {
    	mv.addAttribute("Employee", employee1);
    	mv.addAttribute("Utype", utype);
    	return "ChangePWD";
    }
    
    @RequestMapping("/ChangePass")
    public String changePass(@RequestParam("newpwd") String pass,@RequestParam("empid") int empid,Model mv) {
    	if(vservice.updatePass(empid, pass)) {
    		employee1=vservice.authenticateEmployee(empid,pass);
			mv.addAttribute("Employee", employee1);
	    	mv.addAttribute("Utype", utype);
			return "profile";
    	}
    	mv.addAttribute("Employee", employee1);
    	mv.addAttribute("Utype", utype);
		return "ChangePWD";
    }
    
    @RequestMapping("/takeToProvideHome")
    public String ProviderHome(Model mv) {
    	mv.addAttribute("EmpDetails", employee1);
    	mv.addAttribute("poolDetails", provider1);
		return "ProviderHomePage";
    }

    @RequestMapping("/takeToRiderHome")
    public String RiderHome(Model mv) {
    	mv.addAttribute("EmpDetails", employee1);
    	return "";
    }
}
